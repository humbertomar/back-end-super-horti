<?php

require_once("../../ws/sys/Config.php");

require_once("../../ws/sys/DB.class.php");
require_once("../../ws/sys/DAO.class.php");
require_once("../../ws/sys/Modal.class.php");

require_once ("../../ws/models/Pedidos.class.php");

$param = $_GET['printDiv'];

$pedido = new Pedidos();
$pedido->campos = 'pedido_id, orderId, grandTotal, subTotal, tax, tipo_pagamento, troco, email, name, userid, mobileNo, shippingAddress, observacoes, createdAt, status_pagamento, status_pedido';
$pedido->extras_select = 'WHERE pedido_id = '.$param;
	$pedidoJson = Json_encode($pedido->findAll($pedido));
	//echo json_encode($pedidoJson);
	//print_r($pedidoJson[0]);
	$arrayPedido = json_decode($pedidoJson,true);
	//print_r($arrayPedido);

$itenspedido = new PedidoItems();
$itenspedido->extras_select = 'WHERE pedido_id = '.$param;
$itenspedidoJson = json_encode($itenspedido->findAll($itenspedido));
$arrayItensPedido = json_decode($itenspedidoJson,true);

//echo json_encode($arrayItensPedido);
//print_r($arrayItensPedido);

$url = 'http://superhorti.com.br/appAdmin/';

?>

<!DOCTYPE html>
<html>
   <head>
      <meta charset="utf-8">
      <meta http-equiv="X-UA-Compatible" content="IE=edge">
      <title>SH Delivery</title>
      <!-- Tell the browser to be responsive to screen width -->
      <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
      <!-- Bootstrap 3.3.7 -->
      <link rel="stylesheet" href="http://superhorti.com.br/appAdmin/assets/bower_components/bootstrap/dist/css/bootstrap.min.css">
      <!-- Font Awesome -->
      <link rel="stylesheet" href="http://superhorti.com.br/appAdmin/assets/bower_components/font-awesome/css/font-awesome.min.css">
      <link rel="stylesheet" href="http://superhorti.com.br/appAdmin/assets/dist/css/AdminLTE.min.css">
      <style>
        .aligncenter {
            text-align: center;
        }
        </style>
   </head>
   <body onload="window.print();">
   <!--<body>-->
      <div class="wrapper">
         <section class="invoice">
             
             <p class="aligncenter">
                <img aign="center" src="http://superhorti.com.br/ws/assets/img/logo.jpg" alt="SSHDelivery" height="80">
             </p>
             
            <!-- title row -->
            <div class="row">
               <div class="col-xs-12">
				  <b>Cliente</b>
                  <h2 class="page-header">
                     <?php echo $arrayPedido[0]['name']; ?>
                     <small class="pull-right"><b>Data e Hora do Pedido</b><br /><p><?php
                    $data = new DateTime($arrayPedido[0]['createdAt']);
                    echo $data->format('d/m/Y H:i:s'); 
                  ?></p></small><br />
                  </h2>
               </div>
               <!-- /.col -->
            </div>
            <!-- info row -->
            <div class="row invoice-info">
               <div class="col-sm-4 invoice-col">
                  <b>Cód. do Pedido:</b> <?php echo $arrayPedido[0]['orderId']; ?> <br>
                  
                  <?php
                    $arPedidos = json_decode($arrayPedido[0]['shippingAddress'],true);
                    //print_r($arPedidos);
                  ?>
                  <b>Contato:</b> <?php echo $arPedidos['contato']; ?> <br>
                  <b>Endereço:</b> <?php echo $arPedidos['endereco']; ?> <br>
                  <b>Bairro:</b> <?php echo $arPedidos['bairro']; ?></b> <br>
                  <b>CEP:</b> <?php echo $arPedidos['cep']; ?><br>
               </div>
               <!-- /.col -->
            </div>
            <!-- /.row -->
            <!-- Table row -->
            <div class="row">
               <div class="col-xs-12 table-responsive">
                  <table class="table table-striped">
                     <thead>
                        <tr>
                           <th>Imagem</th>
                            <!--<th>ID</th>-->
                            <th>Produto</th>
                            <th>Valor</th>
                            <th>Quantidade</th>
                            <th>Valor Total</th>
                        </tr>
                     </thead>
                     <tbody>
                        <?php
                        foreach ($arrayItensPedido as $value) {
                        ?>
                        <tr>
                        <th><img src="<?php echo $url.$value['image']; ?>" alt="<?php echo $value['name']; ?>" class="img-circle" width="50" height="50"></th>
                        <!--<th><?php echo $value['id']; ?></th>-->
                        <th><?php echo $value['name']; ?></th>
                        <th><?php echo $value['price']; ?></th>
                        <th><?php echo $value['itemQunatity']; ?></th>
                        <th><?php echo $value['itemTotalPrice']; ?></th>
                        </tr>
                        <?php } ?>
                    </tbody>
                  </table>
               </div>
               <!-- /.col -->
            </div>
            <!-- /.row -->
            <div class="row">
               <div class="col-xs-6 pull pull-right">
                  <div class="table-responsive">
                     <table class="table">
                        <tr>
                           <th>Sub Total do Pedido:</th>
                           <td><?php echo $arrayPedido[0]['subTotal']; ?></td>
                        </tr>
                        <tr>
                           <th>Taxa de Entrega:</th>
                           <td><?php echo $arrayPedido[0]['tax']; ?></td>
                        </tr>
                        <tr>
                           <th style="width:50%">Valor Total do Pedido:</th>
                           <td><?php echo $arrayPedido[0]['grandTotal']; ?></td>
                        </tr>
                        
                        <tr>
                           <th>Status do Pagamento:</th>
                           <td>
                               <?php 
                               switch($arrayPedido[0]['status_pagamento']){
                                    case 1 :
                                        echo "Pendente";
                                    break;
                                    case 2 :
                                        echo "Pago";
                                    break;
                                    case 3 :
                                        echo "Cancelado";
                                    break;
                                    default: "Pendente";
                                }
                               ?>
                            </td>
                        </tr>
                        <tr>
                           <th>Status do Pedido:</th>
                           <td>
                               <?php 
                               switch($arrayPedido[0]['status_pedido']){
                                    case 1 :
                                        echo "Pendente";
                                    break;
                                    case 2 :
                                        echo "Finalizado";
                                    break;
                                    case 3 :
                                        echo "Cancelado";
                                    break;
                                    default: "Pendente";
                                }
                               ?>
                            </td>
                        </tr>
                        <tr>
                           <th>Forma do Pagamento:</th>
                           <td>
                                <?php 
                                switch($arrayPedido[0]['tipo_pagamento']){
                                    case "dinheiro" :
                                        echo "Dinheiro";
                                    break;
                                    case "cartao_credito" :
                                        echo "Cartão de Crédito";
                                    break;
                                    case "cartao_debito" :
                                        echo "Cartão de Débito";
                                    break;
                                    case "transferencia_bancaria" :
                                        echo "Tranferência Bacária";
                                    break;
                                    default: "Dinheiro";
                                }
                                ?>
                            </td>
                        </tr>
                        <tr>
                           <th>Troco:</th>
                           <td>
                            <?php
                                echo $arrayPedido[0]['troco'];
                            ?>
                            </td>
                        </tr>
                     </table>
                  </div>
               </div>
               <!-- /.col -->
            </div>
            <!-- /.row -->
         </section>
         <!-- /.content -->
      </div>
   </body>
</html>
